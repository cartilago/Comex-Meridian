var classOnlineMapsFindAutocompleteResultTerm =
[
    [ "OnlineMapsFindAutocompleteResultTerm", "classOnlineMapsFindAutocompleteResultTerm.html#aa5dfb85500346b4a0870214a0bb1394d", null ],
    [ "offset", "classOnlineMapsFindAutocompleteResultTerm.html#a6dffb30896340649657fb79f2e8c9a75", null ],
    [ "value", "classOnlineMapsFindAutocompleteResultTerm.html#a99757df6a5ee22f955d43a60d45eec4f", null ]
];