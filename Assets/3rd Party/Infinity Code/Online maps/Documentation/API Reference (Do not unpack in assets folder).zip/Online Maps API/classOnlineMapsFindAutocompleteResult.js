var classOnlineMapsFindAutocompleteResult =
[
    [ "OnlineMapsFindAutocompleteResult", "classOnlineMapsFindAutocompleteResult.html#a1ca6827622c06fd94d28a81e25246cd4", null ],
    [ "description", "classOnlineMapsFindAutocompleteResult.html#a8dc6f0d8eecf7367af215e6dd892905c", null ],
    [ "id", "classOnlineMapsFindAutocompleteResult.html#ac50f35c41e8bfeb746f223a3982e4164", null ],
    [ "matchedSubstring", "classOnlineMapsFindAutocompleteResult.html#a02042cddcb83ad9190d7de57b2071ea2", null ],
    [ "place_id", "classOnlineMapsFindAutocompleteResult.html#aa9a318550d4dcca8fa4def78a6732c1a", null ],
    [ "reference", "classOnlineMapsFindAutocompleteResult.html#a3a36cf5c47dfedac4e883deee8d1fd0a", null ],
    [ "terms", "classOnlineMapsFindAutocompleteResult.html#add47f4cbd89cf0776a18956384596b47", null ],
    [ "types", "classOnlineMapsFindAutocompleteResult.html#af9b78d44bdbb9b79578b9e094030ff9d", null ]
];