var classOnlineMapsFindLocationResultAddressComponent =
[
    [ "long_name", "classOnlineMapsFindLocationResultAddressComponent.html#a00b65d7043e6c3c0d08b810f5354964f", null ],
    [ "short_name", "classOnlineMapsFindLocationResultAddressComponent.html#a81177a419e71e2cb1c6fdb747c0ea8f2", null ],
    [ "types", "classOnlineMapsFindLocationResultAddressComponent.html#a85679d6218699aee25b3aabf3f755ebd", null ]
];