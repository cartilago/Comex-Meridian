var classOnlineMapsFindDirectionResult_1_1Leg =
[
    [ "arrival_time", "classOnlineMapsFindDirectionResult_1_1Leg.html#a73ef7285a4e8060c7f2698a0aba1f3a6", null ],
    [ "departure_time", "classOnlineMapsFindDirectionResult_1_1Leg.html#a3e3775e633d3a372ea804c1209e1756c", null ],
    [ "distance", "classOnlineMapsFindDirectionResult_1_1Leg.html#ab0ff090bcad1e9993e630838645ebffc", null ],
    [ "duration", "classOnlineMapsFindDirectionResult_1_1Leg.html#a78db7d7f8e6abc281a0f81eaf85ffa3f", null ],
    [ "duration_in_traffic", "classOnlineMapsFindDirectionResult_1_1Leg.html#a8092c4039d20ed72f5a7d4f2cfeb1064", null ],
    [ "end_address", "classOnlineMapsFindDirectionResult_1_1Leg.html#a5fcf06a2912ba01f471af5a7a36d1890", null ],
    [ "end_location", "classOnlineMapsFindDirectionResult_1_1Leg.html#ac2885043b41a676204a5cac422e02f1c", null ],
    [ "start_address", "classOnlineMapsFindDirectionResult_1_1Leg.html#a846679edaf29bea9d52fbb0b0b097111", null ],
    [ "start_location", "classOnlineMapsFindDirectionResult_1_1Leg.html#adde274dcd57d358609a71a6ce68dd646", null ],
    [ "steps", "classOnlineMapsFindDirectionResult_1_1Leg.html#a392dd03004c429c271cd5056f4c34f8d", null ]
];