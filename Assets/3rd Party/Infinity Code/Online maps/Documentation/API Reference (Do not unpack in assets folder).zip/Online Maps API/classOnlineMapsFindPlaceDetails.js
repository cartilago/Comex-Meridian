var classOnlineMapsFindPlaceDetails =
[
    [ "FindByPlaceID", "classOnlineMapsFindPlaceDetails.html#a933ac5348c6296f866e8757e8ef4a2b3", null ],
    [ "FindByReference", "classOnlineMapsFindPlaceDetails.html#a916589356990a54ffa5cc50664513269", null ],
    [ "GetResult", "classOnlineMapsFindPlaceDetails.html#a3d8cf9ccc713986a634e7d8b91ba1383", null ]
];