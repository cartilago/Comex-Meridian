var classOnlineMapsHereRoutingAPI_1_1RoutingMode_1_1Feature =
[
    [ "Weight", "classOnlineMapsHereRoutingAPI_1_1RoutingMode_1_1Feature.html#a318f122edd009b543611739525b5e7c3", [
      [ "strictExclude", "classOnlineMapsHereRoutingAPI_1_1RoutingMode_1_1Feature.html#a318f122edd009b543611739525b5e7c3a3a3c16edb91e1a7a65754549335e45d2", null ],
      [ "softExclude", "classOnlineMapsHereRoutingAPI_1_1RoutingMode_1_1Feature.html#a318f122edd009b543611739525b5e7c3ab958150ca70c33559accad69853d207f", null ],
      [ "avoid", "classOnlineMapsHereRoutingAPI_1_1RoutingMode_1_1Feature.html#a318f122edd009b543611739525b5e7c3aebc7748dfc82aaa2b35b8d1cc3fdfe7e", null ],
      [ "normal", "classOnlineMapsHereRoutingAPI_1_1RoutingMode_1_1Feature.html#a318f122edd009b543611739525b5e7c3afea087517c26fadd409bd4b9dc642555", null ]
    ] ]
];