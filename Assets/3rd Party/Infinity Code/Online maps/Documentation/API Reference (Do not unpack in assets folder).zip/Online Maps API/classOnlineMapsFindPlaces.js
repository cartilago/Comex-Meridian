var classOnlineMapsFindPlaces =
[
    [ "NearbyParams", "classOnlineMapsFindPlaces_1_1NearbyParams.html", "classOnlineMapsFindPlaces_1_1NearbyParams" ],
    [ "RadarParams", "classOnlineMapsFindPlaces_1_1RadarParams.html", "classOnlineMapsFindPlaces_1_1RadarParams" ],
    [ "RequestParams", "classOnlineMapsFindPlaces_1_1RequestParams.html", null ],
    [ "TextParams", "classOnlineMapsFindPlaces_1_1TextParams.html", "classOnlineMapsFindPlaces_1_1TextParams" ],
    [ "OnlineMapsFindPlacesRankBy", "classOnlineMapsFindPlaces.html#a2e0eeba641497e789555ad2757efb2ba", [
      [ "prominence", "classOnlineMapsFindPlaces.html#a2e0eeba641497e789555ad2757efb2baaf7dcf4a2e0c2d8159278ed77934ddecc", null ],
      [ "distance", "classOnlineMapsFindPlaces.html#a2e0eeba641497e789555ad2757efb2baaa74ec9c5b6882f79e32a8fbd8da90c1b", null ]
    ] ],
    [ "FindNearby", "classOnlineMapsFindPlaces.html#a13fb3a8cf024ccc636e87cb01bc058ac", null ],
    [ "FindNearby", "classOnlineMapsFindPlaces.html#aeeaa1f2f40d3517aa9814a0dda825af2", null ],
    [ "FindRadar", "classOnlineMapsFindPlaces.html#a79a9d3e4215f94a93f8d84c3ec34c1e4", null ],
    [ "FindRadar", "classOnlineMapsFindPlaces.html#ae14f5ef5368c933d02101dad1ba385cf", null ],
    [ "FindText", "classOnlineMapsFindPlaces.html#a9836f2e02b62f5e7c3747548bbe5b0b5", null ],
    [ "FindText", "classOnlineMapsFindPlaces.html#a5591d957e21541d98cbb815cb6c2ea28", null ],
    [ "GetResults", "classOnlineMapsFindPlaces.html#ac54d2e47305ee8e29699cea089350d90", null ],
    [ "GetResults", "classOnlineMapsFindPlaces.html#afff16219100048cb1f4aad43a7c4e8bc", null ]
];