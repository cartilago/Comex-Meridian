var classOnlineMapsFindDirectionResult_1_1GeocodedWaypoint =
[
    [ "geocoder_status", "classOnlineMapsFindDirectionResult_1_1GeocodedWaypoint.html#ad9b58b404af701da913b31a9f85de668", null ],
    [ "partial_match", "classOnlineMapsFindDirectionResult_1_1GeocodedWaypoint.html#a0187a809435bd04a08d0364c38c759be", null ],
    [ "place_id", "classOnlineMapsFindDirectionResult_1_1GeocodedWaypoint.html#a4b104296a5a193a2a04d313ba5577d70", null ],
    [ "types", "classOnlineMapsFindDirectionResult_1_1GeocodedWaypoint.html#ac75714433e182d925757b2663692d267", null ]
];