var classOnlineMapsFindDirectionResult_1_1TransitAgency =
[
    [ "name", "classOnlineMapsFindDirectionResult_1_1TransitAgency.html#ab63e60a5ba957bc328c9ad4a8a56ea3a", null ],
    [ "phone", "classOnlineMapsFindDirectionResult_1_1TransitAgency.html#a59803730ae5382983a1f2c907d907553", null ],
    [ "url", "classOnlineMapsFindDirectionResult_1_1TransitAgency.html#aaa50afc72bec9971cda6dee216b0cb34", null ]
];