var classOnlineMapsFindDirectionResult_1_1TransitDetails =
[
    [ "arrival_stop", "classOnlineMapsFindDirectionResult_1_1TransitDetails.html#ae99ee6fa11c3cefa08a19e5ba7641570", null ],
    [ "arrival_time", "classOnlineMapsFindDirectionResult_1_1TransitDetails.html#a214ccb6f403f100b01a6714d6546cc2c", null ],
    [ "departure_stop", "classOnlineMapsFindDirectionResult_1_1TransitDetails.html#a52a03ebaae221e83a018a838494ea435", null ],
    [ "departure_time", "classOnlineMapsFindDirectionResult_1_1TransitDetails.html#adc39f8b457e37cb66a05db4b27e74590", null ],
    [ "headsign", "classOnlineMapsFindDirectionResult_1_1TransitDetails.html#a0dd0430720e74cd045d553f61776c13d", null ],
    [ "headway", "classOnlineMapsFindDirectionResult_1_1TransitDetails.html#a7c1da20611d0cd56f0c47c52fd11c2be", null ],
    [ "line", "classOnlineMapsFindDirectionResult_1_1TransitDetails.html#a6cb527dc421d33e959bb471171cee4c7", null ],
    [ "num_stops", "classOnlineMapsFindDirectionResult_1_1TransitDetails.html#ae4e1b0ee228cbe97643ff9fa5afb4c6b", null ]
];