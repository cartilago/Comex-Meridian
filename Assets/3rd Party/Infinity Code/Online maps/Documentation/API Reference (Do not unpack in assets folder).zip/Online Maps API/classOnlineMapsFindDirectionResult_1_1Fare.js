var classOnlineMapsFindDirectionResult_1_1Fare =
[
    [ "currency", "classOnlineMapsFindDirectionResult_1_1Fare.html#a22c20228b5bcf8d422e646c167d594a4", null ],
    [ "text", "classOnlineMapsFindDirectionResult_1_1Fare.html#a042b95fb69f4a6b7be58d8d732120509", null ],
    [ "value", "classOnlineMapsFindDirectionResult_1_1Fare.html#a95da978fe768d7266f5702f38b380d31", null ]
];