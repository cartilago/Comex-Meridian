var classOnlineMapsGPXObject_1_1Copyright =
[
    [ "Copyright", "classOnlineMapsGPXObject_1_1Copyright.html#ac0d066103f222c32db36cb60748407f3", null ],
    [ "Copyright", "classOnlineMapsGPXObject_1_1Copyright.html#a03d0220ff7f66bea341ca0b98e9934e2", null ],
    [ "author", "classOnlineMapsGPXObject_1_1Copyright.html#a2ed6566f337746c318ce173241a193e8", null ],
    [ "license", "classOnlineMapsGPXObject_1_1Copyright.html#aa1e1b7fd2681de49dc70677e246a18a4", null ],
    [ "year", "classOnlineMapsGPXObject_1_1Copyright.html#aec3d818b0f654b03f85dcff733222ce6", null ]
];