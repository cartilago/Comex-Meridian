var classOnlineMapsFindDirectionResult_1_1Vehicle =
[
    [ "icon", "classOnlineMapsFindDirectionResult_1_1Vehicle.html#a5065e7796af739c13498b839ac3820f6", null ],
    [ "local_icon", "classOnlineMapsFindDirectionResult_1_1Vehicle.html#abd91fc2c985a9de2e3df6b10b71a7def", null ],
    [ "name", "classOnlineMapsFindDirectionResult_1_1Vehicle.html#a32265c2f0c476e016a0f603512a7e2cd", null ],
    [ "type", "classOnlineMapsFindDirectionResult_1_1Vehicle.html#a1daa4d7e44cea5ae28e0da8ddaafae65", null ]
];