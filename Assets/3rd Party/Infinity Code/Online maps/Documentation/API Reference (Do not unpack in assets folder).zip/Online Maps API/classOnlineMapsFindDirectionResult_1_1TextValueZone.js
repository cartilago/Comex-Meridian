var classOnlineMapsFindDirectionResult_1_1TextValueZone =
[
    [ "text", "classOnlineMapsFindDirectionResult_1_1TextValueZone.html#afa8492a0f5eafd7063c801c0205a5b96", null ],
    [ "time_zone", "classOnlineMapsFindDirectionResult_1_1TextValueZone.html#a5df69a20cd9317ac4788cb08fd5a0d9c", null ],
    [ "value", "classOnlineMapsFindDirectionResult_1_1TextValueZone.html#a257f75441f566cc2769b267aefe78514", null ]
];