var classOnlineMapsFindAutocompleteResultMatchedSubstring =
[
    [ "OnlineMapsFindAutocompleteResultMatchedSubstring", "classOnlineMapsFindAutocompleteResultMatchedSubstring.html#ae7e3a6025d54416403b6ad826b3f0268", null ],
    [ "length", "classOnlineMapsFindAutocompleteResultMatchedSubstring.html#afb9a07cf65d7fcd8578a81a90370d0ac", null ],
    [ "offset", "classOnlineMapsFindAutocompleteResultMatchedSubstring.html#a317bfbc8083057b97a5a37d9029f6e18", null ]
];