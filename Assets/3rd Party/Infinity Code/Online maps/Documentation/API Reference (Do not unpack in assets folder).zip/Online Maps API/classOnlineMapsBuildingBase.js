var classOnlineMapsBuildingBase =
[
    [ "OnlineMapsBuildingRoofType", "classOnlineMapsBuildingBase.html#a0a18912ebeb915f6e59fa6168c1f0d4b", [
      [ "dome", "classOnlineMapsBuildingBase.html#a0a18912ebeb915f6e59fa6168c1f0d4ba1b71c8e9e749753da4e8f55b029ced5f", null ],
      [ "flat", "classOnlineMapsBuildingBase.html#a0a18912ebeb915f6e59fa6168c1f0d4ba37fc7edee25a177474eaebe7f7b09785", null ]
    ] ],
    [ "CheckIgnoredBuildings", "classOnlineMapsBuildingBase.html#aa19160f809595d2c8d9a399de4396d09", null ],
    [ "CreateGameObject", "classOnlineMapsBuildingBase.html#a2420fdc36b6a9ff93f9a0983e7e3010f", null ],
    [ "Dispose", "classOnlineMapsBuildingBase.html#ad1b1ab2e19100fc908a0facf074c9682", null ],
    [ "GetLocalPoints", "classOnlineMapsBuildingBase.html#a1b135479800dac740c53b56d1bacc5d4", null ],
    [ "LoadMeta", "classOnlineMapsBuildingBase.html#a382a6459e07c68214bbfd0ad7dc1bb2e", null ],
    [ "OnBasePress", "classOnlineMapsBuildingBase.html#acd8d59730b25d6db9cb1dc424e9856fa", null ],
    [ "OnBaseRelease", "classOnlineMapsBuildingBase.html#a5dea7614882bc59f3249cbdd6f494da9", null ],
    [ "OnMouseDown", "classOnlineMapsBuildingBase.html#a003deb39305b14212c82d282c2fcfb8e", null ],
    [ "OnMouseUp", "classOnlineMapsBuildingBase.html#ae2708ce2d64b6827f5cb024b3ca7b80a", null ],
    [ "boundsCoords", "classOnlineMapsBuildingBase.html#a25d1fcd020ddd4522d3d24468a652298", null ],
    [ "buildingCollider", "classOnlineMapsBuildingBase.html#a543ca5e5a3c738714fedb833bfbad941", null ],
    [ "centerCoordinates", "classOnlineMapsBuildingBase.html#a1f2356cdf9c4c97a5700d0e4cf9ab5ad", null ],
    [ "hasErrors", "classOnlineMapsBuildingBase.html#a2abe280321bc480da015d219334a0ce6", null ],
    [ "id", "classOnlineMapsBuildingBase.html#a60d10315ef64ffa4bf27b962fd962f8f", null ],
    [ "initialZoom", "classOnlineMapsBuildingBase.html#a3d9d370a481afe18db646f6dd10de60f", null ],
    [ "metaInfo", "classOnlineMapsBuildingBase.html#ae4b2f8f22f5bcbffd2d3dd26834cfbb9", null ],
    [ "OnClick", "classOnlineMapsBuildingBase.html#a4c8789cca999dbcfe10e380dc72536c1", null ],
    [ "OnDispose", "classOnlineMapsBuildingBase.html#aa91fc878c86cd3e4e2c6d32edb49e401", null ],
    [ "OnPress", "classOnlineMapsBuildingBase.html#afd8809536a3ea387dcf981b3e37258df", null ],
    [ "OnRelease", "classOnlineMapsBuildingBase.html#a6005b6ebef46767311131ee862dbb390", null ],
    [ "perimeter", "classOnlineMapsBuildingBase.html#a7ba0ff10f5592f5a98814abd2148e0d5", null ]
];