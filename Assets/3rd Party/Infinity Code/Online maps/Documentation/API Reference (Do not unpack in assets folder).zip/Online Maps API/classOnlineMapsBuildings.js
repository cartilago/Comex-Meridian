var classOnlineMapsBuildings =
[
    [ "buildingContainer", "classOnlineMapsBuildings.html#ad7f0a4c4a728675c798a5968aaac56ad", null ],
    [ "heightScale", "classOnlineMapsBuildings.html#aeb34647dd1b23a9b4ce19e84d5c146ed", null ],
    [ "levelHeight", "classOnlineMapsBuildings.html#acf2f8602588eeca644e4c28c1c3d8dd8", null ],
    [ "levelsRange", "classOnlineMapsBuildings.html#a71a7d705410299cfbdd02a2084f54253", null ],
    [ "materials", "classOnlineMapsBuildings.html#a50e3ec908acab9682de4d23a57c1ef36", null ],
    [ "maxActiveBuildings", "classOnlineMapsBuildings.html#ab7b3bcc14d4a1447b466a52a01a897aa", null ],
    [ "maxBuilding", "classOnlineMapsBuildings.html#a5547f2f944a56cb5fe816bb0c9f1607d", null ],
    [ "minHeight", "classOnlineMapsBuildings.html#a9e48d83813b36c794697e1f0172f2d59", null ],
    [ "OnBuildingCreated", "classOnlineMapsBuildings.html#ab7bf6d7e6752f31dc2c93f72246c0d9e", null ],
    [ "OnBuildingDispose", "classOnlineMapsBuildings.html#a9857dabb05d65dfb4c3943be94f7bde0", null ],
    [ "OnCreateBuilding", "classOnlineMapsBuildings.html#ad206972848b444d5f5b2b7efc491f761", null ],
    [ "OnGenerateBuildingHeight", "classOnlineMapsBuildings.html#ade341b03ac55057c48c62727c087c780", null ],
    [ "OnNewBuildingsReceived", "classOnlineMapsBuildings.html#a2335c399b7e2ab9b3e1fa777b60fa29b", null ],
    [ "OnPrepareRequest", "classOnlineMapsBuildings.html#ac84033d2207e98060c4aa53397dcb37e", null ],
    [ "OnRequestComplete", "classOnlineMapsBuildings.html#af787d6ead4b3848bdecef3884857b123", null ],
    [ "OnRequestSent", "classOnlineMapsBuildings.html#a927575db0d0698d4f3da1d6b0f06062e", null ],
    [ "OnShowBuilding", "classOnlineMapsBuildings.html#a1a17049c91e8b2cc97ce327f401c4e3e", null ],
    [ "zoomRange", "classOnlineMapsBuildings.html#a129130328c8662fae51ab48175e188c3", null ],
    [ "activeBuildings", "classOnlineMapsBuildings.html#af424e8521e826f90fb64517bd3aee407", null ],
    [ "instance", "classOnlineMapsBuildings.html#a962b793e781143ad4512943024101922", null ]
];