var classOnlineMapsFindDirectionResult_1_1TextValue =
[
    [ "text", "classOnlineMapsFindDirectionResult_1_1TextValue.html#a2ca7b54bcbc35a369e6036f287246b61", null ],
    [ "value", "classOnlineMapsFindDirectionResult_1_1TextValue.html#afb3b7d84b1e4d509d1b642f22276221e", null ]
];