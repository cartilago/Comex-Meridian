var classOnlineMapsFindDirectionAdvanced =
[
    [ "Params", "classOnlineMapsFindDirectionAdvanced_1_1Params.html", "classOnlineMapsFindDirectionAdvanced_1_1Params" ],
    [ "TrafficModel", "classOnlineMapsFindDirectionAdvanced.html#aabd1cc3a38c293bb4ccfe19ff08cfefc", [
      [ "bestGuess", "classOnlineMapsFindDirectionAdvanced.html#aabd1cc3a38c293bb4ccfe19ff08cfefcae7c19d13bd2f5f6766eeb1eefadf2421", null ],
      [ "pessimistic", "classOnlineMapsFindDirectionAdvanced.html#aabd1cc3a38c293bb4ccfe19ff08cfefca70c80cb25b21e8bac39f4be0cf902626", null ],
      [ "optimistic", "classOnlineMapsFindDirectionAdvanced.html#aabd1cc3a38c293bb4ccfe19ff08cfefca9a0d734a8cc94890376ad2b82e3771e3", null ]
    ] ],
    [ "TransitMode", "classOnlineMapsFindDirectionAdvanced.html#aac96df9a6ccf1b690e36caa7752b5a1f", [
      [ "bus", "classOnlineMapsFindDirectionAdvanced.html#aac96df9a6ccf1b690e36caa7752b5a1fad20f83ee6933aa1ea047fe5cbd9c1fd5", null ],
      [ "subway", "classOnlineMapsFindDirectionAdvanced.html#aac96df9a6ccf1b690e36caa7752b5a1fade80593878cb1673c62a7f338dc7e4e1", null ],
      [ "train", "classOnlineMapsFindDirectionAdvanced.html#aac96df9a6ccf1b690e36caa7752b5a1fa61b3a8faa9c1091806675c230a9abe64", null ],
      [ "tram", "classOnlineMapsFindDirectionAdvanced.html#aac96df9a6ccf1b690e36caa7752b5a1faecb1da74e8ff8fdd2911197ecf8badc0", null ],
      [ "rail", "classOnlineMapsFindDirectionAdvanced.html#aac96df9a6ccf1b690e36caa7752b5a1fa70036b7bb753dee338a8a6baa67e2103", null ]
    ] ],
    [ "TransitRoutingPreference", "classOnlineMapsFindDirectionAdvanced.html#aec1b5e777297100f50ce07d3a86975f6", [
      [ "lessWalking", "classOnlineMapsFindDirectionAdvanced.html#aec1b5e777297100f50ce07d3a86975f6adc4f526e463e5efaae116af0359a25b1", null ],
      [ "fewerTransfers", "classOnlineMapsFindDirectionAdvanced.html#aec1b5e777297100f50ce07d3a86975f6aa0847859a0c887028a8f1e8054c2c092", null ]
    ] ],
    [ "Find", "classOnlineMapsFindDirectionAdvanced.html#aa808ed290b1ee7171c07f46317c9faf1", null ],
    [ "Find", "classOnlineMapsFindDirectionAdvanced.html#abd43c11cbb961c7b2281ed0214d85c94", null ],
    [ "Find", "classOnlineMapsFindDirectionAdvanced.html#a1b78d05be28e76c099a58b168a5bb76d", null ],
    [ "Find", "classOnlineMapsFindDirectionAdvanced.html#aa55589b5c5b28e45fa8b640fffa0b27b", null ]
];