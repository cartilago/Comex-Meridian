var searchData=
[
  ['query',['query',['../classOnlineMapsFindPlaces_1_1TextParams.html#a6b00df9683a77426f6be7f95beab095e',1,'OnlineMapsFindPlaces::TextParams']]]
];
