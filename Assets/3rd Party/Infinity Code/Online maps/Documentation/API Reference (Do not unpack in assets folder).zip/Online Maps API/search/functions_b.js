var searchData=
[
  ['nearbyparams',['NearbyParams',['../classOnlineMapsFindPlaces_1_1NearbyParams.html#a7092b4714467693e2abb7285f615cd63',1,'OnlineMapsFindPlaces.NearbyParams.NearbyParams(Vector2 lnglat, int radius)'],['../classOnlineMapsFindPlaces_1_1NearbyParams.html#a28af281ff89fa4766864f6e755cc6205',1,'OnlineMapsFindPlaces.NearbyParams.NearbyParams(string pagetoken)']]]
];
