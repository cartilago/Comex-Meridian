var searchData=
[
  ['vehicle',['Vehicle',['../classOnlineMapsFindDirectionResult_1_1Vehicle.html',1,'OnlineMapsFindDirectionResult']]],
  ['vehicletype',['VehicleType',['../classOnlineMapsHereRoutingAPI_1_1VehicleType.html',1,'OnlineMapsHereRoutingAPI']]],
  ['viawaypoint',['ViaWaypoint',['../classOnlineMapsFindDirectionResult_1_1ViaWaypoint.html',1,'OnlineMapsFindDirectionResult']]]
];
