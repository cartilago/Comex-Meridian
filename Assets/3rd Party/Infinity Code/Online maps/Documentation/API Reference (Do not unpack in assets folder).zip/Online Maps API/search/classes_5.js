var searchData=
[
  ['incident',['Incident',['../classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Incident.html',1,'OnlineMapsHereRoutingAPIResult::Route']]]
];
